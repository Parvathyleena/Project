from django.db import models

# Create your models here
class login(models.Model):
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=20)
class Registration(models.Model):
    Name=models.CharField(max_length=30)
    cource=models.CharField(max_length=30)
    gender=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    