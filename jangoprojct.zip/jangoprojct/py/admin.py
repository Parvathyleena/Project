from django.contrib import admin

# Register your models here.
from py.models import login
admin.site.register(login)
from py.models import Registration
admin.site.register(Registration)