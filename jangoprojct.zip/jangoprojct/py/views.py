from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'km.html')
def aboutus(request):
    return render(request,'aboutus.html')
def contact(request):
    return render(request,'contact.html')
def login(request):
    if request.method=="POST":
        un=request.POST['uname']
        pwd=request.POST['pass']
        print("username=",un)
        print("password=",pwd)
    return render(request,'login.html')
def registeration(request):
    if request.method=="POST":
        a=request.POST['firstname']
        b=request.POST['middlename']
        c=request.POST['lastname']
        d=request.POST['course']
        e=request.POST['Gender']
        f=request.POST['Phone']
        g=request.POST['Address']
        h=request.POST['Email']
        i=request.POST['Password']
        j=request.POST['Re-type password']
        print("firstnmae=",a)
        print("middlename=",b)
        print("lastname=",c)
        print("Course=",d)
        print("Gender=",e)
        print("Phone=",f)
        print("Address=",g)
        print("Email=",h)
        print("Password=",i)
        print("Re-type password=",j)
    return render(request,'registeration.html')