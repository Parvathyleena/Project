from django.apps import AppConfig


class PyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'py'
