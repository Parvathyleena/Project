from django.urls import path
from . import views
urlpatterns = [
    path('',views.home),
    path('aboutus',views.aboutus),
    path('contact',views.contact),
    path('login',views.login),
    path('registeration',views.registeration),
]